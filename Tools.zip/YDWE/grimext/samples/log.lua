log("log") -- all these strings are written to logs/grimex.txt
logf("l", "o", "g", "f")
logt({ "l", "o", "g", "t" })