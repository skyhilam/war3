setvalue("CmdRally","Hotkey","H")
mergefile("TestMisc.txt")
mergefile("TestSkin.txt")
mergefile("TestExtra.txt")