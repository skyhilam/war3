w3x2txt
=======
* 将地图拖动make.bat中:将地图的部分二进制文件转换成文本文件,输出目录为"input" (地图需要有完整listfile)

* 双击make.bat:将txt目录中的文本文件转换为地图用的二进制文件,输出目录为"output"

* 如果地图使用了自定义UI,需要将自定义的TriggerData.txt复制到meta中
